from mensajes.hola.saludos import *
from mensajes.adios.despedidas import *

saludar()
Saludo()

despedir()
Despedida()